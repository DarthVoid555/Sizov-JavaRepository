package geometry2d;

public interface Figure {
    double area();
    double perimeter();
    String toString();
}