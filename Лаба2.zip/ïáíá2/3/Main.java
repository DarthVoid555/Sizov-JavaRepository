public class Main {
    public static void main(String[] args) {
        Bell ringer = new Bell();
        ringer.sound();
        ringer.sound();
        ringer.sound();
        ringer.sound();ringer.sound();
        ringer.sound();

    }
}